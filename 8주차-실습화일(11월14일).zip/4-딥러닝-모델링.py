'''
***********************************************
데이터 불러오기
***********************************************

가. 라이브러리 Import

'''
import pandas as pd
import numpy as np

'''
나. 데이터 불러오기
'''

df_feature = pd.read_csv("navi_train_feature.csv",sep="|")
df_target = pd.read_csv("navi_train_target.csv",sep="|")

'''
나. Train/Test Data Split
'''

from sklearn.model_selection import train_test_split

# train_test_split
train_x, test_x, train_y, test_y = train_test_split(df_feature, df_target, test_size=0.20, random_state=42)

'''
------------------------------------------------
1. 회귀문제에 딥러닝 모델 적용하기
------------------------------------------------
  딥러닝은 머신 러닝의 특정한 한 분야로서 연속된 layer들에서 w값 학습 


가. 라이브러리 Import
'''

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from keras.callbacks import ModelCheckpoint, EarlyStopping

'''
나. 모델링

'''

# train 데이터 셋을 확인해보겠습니다.
pd.set_option('display.max_columns', None)  # 컬럼 생략 없이 전부 출력
train_x

# 모델 만들기 : 아주 간단한 모델
# 다음 함수정의 코드는 한번에 선택하여 실행하여야 함. => 59행부터 69행까지 마우스로 마킹한 후, run selection으로 실행

def build_model():
  model = keras.Sequential([
    layers.Dense(64, activation='relu', input_shape=[len(train_x.keys())]),
    layers.Dense(64, activation='relu'),
    layers.Dense(1)
  ])

  model.compile(loss='mean_squared_error',
                optimizer='adam',
                metrics=['mae', 'mse'])
  return model

'''
분류문제의 경우

1. activation설정
    - 마지막 출력층에 Label의 열이 하나고 두 개의 값으로 이루어진 이진분류라면 sigmoid
    - Label의 열이 두개 이상이라면 softmax

2. loss설정
   - 출력층 activation이 sigmoid 인 경우: binary_crossentropy
   - 출력층 activation이 softmax 인 경우: “정답이 숫자면 sparse_, 원핫이면 일반 categorical_
   -  원핫인코딩(O): categorical_crossentropy
   -  원핫인코딩(X): sparse_categorical_crossentropy
3. metrics를 'acc' 혹은 'accuracy'로 지정하여, 학습시 정확도를 모니터링 

'''

# 원핫인코딩 여부 체크방법

# Case1 : 원핫인코딩이 안된 데이터
temp_y=[9,5,6,7,1,2,5,4,6,0]
temp_y[0]

# Case2 : 원핫인코딩 적용
print(tf.one_hot(temp_y[0], 10))
print(tf.one_hot(temp_y, 10))



model = build_model()
model.summary()

# 모델 학습
'''
에러 메시지 요약:
save_weights_only=True를 사용하는 경우, ModelCheckpoint의 저장 경로(filepath)는 반드시 .weights.h5로 끝나야 한다는 뜻입니다.


'''

# 모델 학습 중 특정 기준을 모니터링하다가, 성능이 개선되지 않으면 학습을 멈춤
early_stopping = EarlyStopping(monitor='val_loss', patience=10) # 조기종료 콜백함수 정의

#checkpoint_path = 'tmp_checkpoint.ckpt'
checkpoint_path = 'tmp_checkpoint.weights.h5'

# 131행부터 132행까지 마우스로 마킹한 후, run selection으로 실행
cb_checkpoint = ModelCheckpoint(checkpoint_path, save_weights_only=True, monitor='val_loss',
                               verbose=1, save_best_only=True) # 체크포인트 저장

# 121행부터 124행까지 마우스로 마킹한 후, run selection으로 실행
history = model.fit(train_x, train_y, epochs=30,  
                   validation_data = (test_x,test_y),
                    callbacks=[cb_checkpoint, early_stopping]
                    )


plt.style.use("ggplot")
plt.figure()
plt.plot(np.arange(0, 30), history.history["loss"], label="train_loss")
plt.plot(np.arange(0, 30), history.history["val_loss"], label="val_loss")
plt.title("Training Loss")
plt.xlabel("Epoch #")
plt.ylabel("Loss")
plt.legend()
plt.show()  # 오른쪽 상단 변수창 [Plots] 탭에서 확인

plt.style.use("ggplot")
plt.figure()
plt.plot(np.arange(0, 30), history.history["mae"], label="train_mae") #mae는 평균 절대 오차 (Mean Absolute Error)
plt.plot(np.arange(0, 30), history.history["val_mae"], label="val_mae")
plt.title("Training mae")
plt.xlabel("Epoch #")
plt.ylabel("mae")
plt.legend()
plt.show() # 오른쪽 상단 변수창 [Plots] 탭에서 확인

# 최적 모델 불러오기 및 저장
model.load_weights(checkpoint_path)
model.save("DeeplearningModel.h5")


from tensorflow.keras.models import load_model
new_model = load_model("DeeplearningModel.h5")

from tensorflow.keras.models import load_model
from tensorflow.keras.losses import MeanSquaredError

new_model = load_model("DeeplearningModel.h5", custom_objects={'mse': MeanSquaredError()})


from sklearn.metrics import roc_auc_score, accuracy_score, mean_squared_error, r2_score
from math import sqrt

pred_y = new_model.predict(test_x)

mse = mean_squared_error(test_y, pred_y)
rmse = sqrt(mse)
mpe = abs(np.mean((test_y - pred_y) / test_y) * 100)
rs = r2_score(test_y,pred_y)


print("RMSE on Test set : {0:.5f}".format(rmse))
print("MPE on Test set : {0:.1f}% 오차 발생 ".format(mpe))
print("R-squared Score on Test set : {0:.5f}".format(rs))


'''
27일 이후 데이터로 예측 평가
'''


eval_feature = pd.read_csv("navi_eval_feature.csv",sep="|")
eval_target = pd.read_csv("navi_eval_target.csv",sep="|")



