'''
########################################
데이터 불러오기부터 머신러닝 모델링까지
########################################

가. 라이브러리 Import

'''

import pandas as pd
import numpy as np

'''
나. 데이터 불러오기
'''

pd.set_option('display.max_columns', None)  # 컬럼 생략 없이 전부 출력
df_feature = pd.read_csv("navi_train_feature.csv",sep="|")
df_target = pd.read_csv("navi_train_target.csv",sep="|")
df_feature
df_target.info()
temp = df_feature.columns

'''
*********************************************
1. Train/Test Data Split
*********************************************
Overfitting을 방지하기위해 데이터 셋을 분할
     - KeyPoint : 학습 대상으로 정제한 데이터를 Train/Test 데이터로 분할
'''

from sklearn.model_selection import train_test_split

# train_test_split : 테스트 데이터 20%
train_x, test_x, train_y, test_y = train_test_split(df_feature, df_target, test_size=0.20, random_state=42)
train_x.shape

'''


****************************************
2. Modeling
****************************************

 머신러닝 라이브러리를 토대로 모델링


- 모델의 평가 기준은 RMSE와 R-squared Score로 한다.(다른 평가 기준도 있으나, 본 실습에서는 두 가지로 진행)
- RMSE(Root Mean Squared Error) : (예측 값-실제 값) 제곱의 평균에 루트한 값으로 모델의 예측 값과 실제 값의 차이를 표현
- R-squared Score : 우리말로 결정계수라고 할 수 있는데, 모델의 설명력을 평가하기 위한 지표(0~1사이의 값, 1에 가까울수록 설명력이 높음)

-----------------------------------------
가. LinearRegression 
-----------------------------------------

'''

from sklearn.linear_model import LinearRegression as lr
from sklearn.metrics import roc_auc_score, accuracy_score, mean_squared_error, r2_score
from math import sqrt

model = lr()
model.fit(train_x, train_y)

print("모델의 회귀계수는 : ", model.coef_, "이고 모델의 절편은 : ",model.intercept_)

pred_y = model.predict(test_x)

mse = mean_squared_error(test_y, pred_y)
rmse = sqrt(mse)
test_y.describe()

mpe = abs(np.mean((test_y - pred_y) / test_y) * 100)
rs = r2_score(test_y,pred_y)



print("RMSE on Test set : {0:.5f}".format(rmse))
print("MPE on Test set : {0:.1f}% 오차 발생 ".format(mpe))
print("R-squared Score on Test set : {0:.5f}".format(rs))


'''
***********************************************************************************
나. 앙상블(Ensemble) 기법 => Random Forest, Gradient Boosting, XGBoost
***********************************************************************************

- 앙상블은 크게 Bagging과 Boosting으로 구분
- Bagging : Bootstrap Aggregating의 줄임말로 그대로 풀어보면 여러 개의 bootstrap을 생성하고 합쳐서(Aggregating)
 최종 예측 모델을 산출하는 방법  => RandomForest
                               => 병렬학습 가능
- Boosting :  여러 모델을 순차적으로 학습해서 이전 모델의 결과를 바탕으로 다음 모델을 학습
              이 과정을 통해 모델은 틀린 부분에 가중치를 부여하는 방식으로 오류를 더 잘 잡아낼 수 있도록 고안된 기법
              Bagging이 일반적인 모델을 여러개 생성하는데 집중한다면 Boosting은 정답을 찾기 어려운 문제에 집중
              
-----------------------
1) 렌덤포레스트
-----------------------
Bagging의 일종으로 의사결정나무(Decision Tree) 여러 개를 모아서 숲을 랜덤으로 구성하고 이를 종합해서 최종 모델을 산출하는 기법.
[주요 하이퍼 파라미터]

- n_estimators : 의사결정나무의 갯수를 지정, 많을 수록 좋은 결과 값을 기대할 수 있으나, 시간도 비례해서 증가(default 10)
- max_depth : 트리의 최대 깊이을 설정하는 것으로, 깊어질수록 과적합의 가능성이 높아진다.(default None)
- min_samples_split : 노드를 나눌 수 있는 최소 데이터 수(default 2)
- min_samples_leaf : 잎이 될 수 있는 최소 데이터 수(default 1)
'''

from sklearn.ensemble import RandomForestRegressor as rfr
from sklearn.metrics import roc_auc_score, accuracy_score, mean_squared_error, r2_score

'''
# 다차원 배열을 1차원으로 평평하게 만들어주기!
# 머신러닝에서는 타깃변수가 1차원이어야 함
# [[0],
 [1],
 [0],
 [1]]
                                      => [0, 1, 0, 1]
'''                                      
train_y = np.ravel(train_y)  # 1차원 데이터프레임을 행렬구조로 변환 

model=rfr(n_estimators=100,max_depth=5,min_samples_split=30,min_samples_leaf=15)
model.fit(train_x, train_y)  


pred_y = model.predict(test_x)
test_y = np.ravel(test_y) 

mse = mean_squared_error(test_y, pred_y)
rmse = sqrt(mse)
mpe = abs(np.mean((test_y - pred_y) / test_y) * 100)
rs = r2_score(test_y,pred_y)



print("RMSE on Test set : {0:.5f}".format(rmse))
print("MPE on Test set : {0:.1f}% 오차 발생 ".format(mpe))
print("R-squared Score on Test set : {0:.5f}".format(rs))


# Feature의 중요도 확인
'''
import matplotlib.pyplot as plt
import seaborn as sns
'''

import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib
from matplotlib import font_manager

# 한글 폰트 설정
font_path = "c:/test/malgun.ttf"
font_name = font_manager.FontProperties(fname=font_path).get_name()
matplotlib.rc('font', family=font_name)
matplotlib.rcParams['axes.unicode_minus'] = False

# 중요도 시각화
rf_importances_values = model.feature_importances_
rf_importances = pd.Series(rf_importances_values, index=train_x.columns)
rf_top10 = rf_importances.sort_values(ascending=False)[:10]

# Tools -> Preference -> IPython Console -> Graphics ->Backend: inline
plt.figure(figsize=(8, 6))
plt.title('Top 10 Feature Importances')
sns.barplot(x=rf_top10, y=rf_top10.index, palette="RdBu", hue=None, legend=False)
plt.show()  # 오른쪽 상단 변수창의 [Plots] 탭에서 확인


'''
-----------------------------
2) GradientBoosting
-----------------------------
이전 모델의 오차를 다음 모델이 경사하강법으로 보정하면서 학습모델 생성과정 반복 => 강한 분류기 생성
'''

from sklearn.ensemble import GradientBoostingRegressor as grb
from sklearn.metrics import roc_auc_score, accuracy_score, mean_squared_error, r2_score

# 다차원 배열을 1차원으로 평평하게 만들어주기!
train_y = np.ravel(train_y, order='C')

model=grb(n_estimators=100,learning_rate=0.1,max_depth=5,min_samples_split=30,min_samples_leaf=15)
model.fit(train_x, train_y)

pred_y = model.predict(test_x)
test_y = np.ravel(test_y) 

mse = mean_squared_error(test_y, pred_y)
rmse = sqrt(mse)
mpe = abs(np.mean((test_y - pred_y) / test_y) * 100)
rs = r2_score(test_y,pred_y)


print("RMSE on Test set : {0:.5f}".format(rmse))
print("MPE on Test set : {0:.1f}% 오차 발생 ".format(mpe))
print("R-squared Score on Test set : {0:.5f}".format(rs))



grb_importances_values = model.feature_importances_
grb_importances = pd.Series(grb_importances_values, index = train_x.columns)
grb_top10 = grb_importances.sort_values(ascending=False)[:10]

#plt.rcParams["font.family"] = 'NanumGothicCoding'
plt.figure(figsize=(8,6))
plt.title('Top 10 Feature Importances for GradientBoosting')
#sns.barplot(x=grb_top10, y=grb_top10.index,palette = "RdBu")
sns.barplot(x=rf_top10, y=grb_top10.index, palette="RdBu", hue=None, legend=False)
plt.show() # 오른쪽 상단 변수창의 [Plots] 탭에서 확인


'''
----------------------------
3) XGBoost
----------------------------
Boosting 모델이 강력한 것은 사실이지만 단점도 존재(느리고, 과적합의 이슈), 
그래서 GradientBoosting보다 빠르고 규제를 설정해서 과적합 방지가 가능한 XGBoost가 등장
[주요 하이퍼 파라미터]

- booster : 사용할 부스터(default gbtree)
- gamma : 트리 분할 시 손실이 특정 값 이상 이상 줄어들어야 분할 허용(default 0) -> 과적합 방지
- eta : 학습률 (learning rate). 한 번의 학습에서 가중치 업데이트 크기 → 작을수록 천천히 학습, 안정적
- n_estimators : 트리갯수
- max_depth : 트리의 최대 깊이.(default 6)
- reg_lambda :특정변수(컬럼)에 너무 의존하지 않도록 설정 => 특정변수에 가중치가 많아지면 설정값 만큼벌점 부여 
              => 값이 클수록 튀는 변수가 없어짐  커질수록 오버피팅 방지, 너크 크면 과소적합 =>적정값(1~10)
- reg_alpha : 특정변수(컬럼)에 너무 의존하지 않도록 설정 => 특정변수에 가중치가 많아지면 설정값 만큼벌점 부여 
              => 값이 클수록 튀는 변수가 없어짐  커질수록 오버피팅 방지, 적정값(0~5)
'''

from xgboost import XGBRegressor as xgb
from sklearn.metrics import roc_auc_score, accuracy_score, mean_squared_error, r2_score

# 다차원 배열을 1차원으로 평평하게 만들어주기!
train_y = np.ravel(train_y, order='C')

model=xgb(n_estimators=100,gamma=1,eta=0.1,max_depth=5,reg_lambda=5,reg_alpha=5)
model.fit(train_x, train_y)

pred_y = model.predict(test_x)
test_y = np.ravel(test_y) 

mse = mean_squared_error(test_y, pred_y)
rmse = sqrt(mse)
mpe = abs(np.mean((test_y - pred_y) / test_y) * 100)
rs = r2_score(test_y,pred_y)


print("RMSE on Test set : {0:.5f}".format(rmse))
print("MPE on Test set : {0:.1f}% 오차 발생 ".format(mpe))
print("R-squared Score on Test set : {0:.5f}".format(rs))



import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 중요도 추출
xgb_importances_values = model.feature_importances_
xgb_importances = pd.Series(xgb_importances_values, index=train_x.columns)
xgb_top10 = xgb_importances.sort_values(ascending=False)[:10]

# Series → DataFrame 변환
df_top10 = xgb_top10.reset_index()
df_top10.columns = ['feature', 'importance']

# 시각화
plt.figure(figsize=(8, 6))
plt.title('Top 10 Feature Importances')
sns.barplot(data=df_top10, x='importance', y='feature', palette="RdBu", hue=None, legend=False)
plt.show()   # 오른쪽 상단 변수창의 [Plots] 탭에서 확인







































