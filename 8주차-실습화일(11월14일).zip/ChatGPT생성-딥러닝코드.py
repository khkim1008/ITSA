import pandas as pd
import numpy as np
from tensorflow import keras
from tensorflow.keras import layers
from sklearn.metrics import mean_squared_error, r2_score
from math import sqrt

# -------------------------------
# 2️⃣ 데이터 불러오기
# -------------------------------
X = pd.read_csv("navi_train_feature.csv")
y = pd.read_csv("navi_train_target.csv")

# -------------------------------
# 3️⃣ 모델 구성
# -------------------------------
model = keras.Sequential([
    layers.Dense(64, activation='relu', input_shape=[X.shape[1]]),
    layers.Dense(64, activation='relu'),
    layers.Dense(1)
])

# -------------------------------
# 4️⃣ 모델 컴파일 및 학습
# -------------------------------
model.compile(optimizer='adam', loss='mse', metrics=['mae', 'mse'])
history = model.fit(X, y, epochs=30, validation_split=0.2, verbose=1)

# -------------------------------
# 5️⃣ 예측 및 성능평가
# -------------------------------
pred_y = model.predict(X)

# RMSE
rmse = sqrt(mean_squared_error(y, pred_y))

# MPE (평균 백분율 오차)
mpe = np.mean((y.values.flatten() - pred_y.flatten()) / y.values.flatten()) * 100

# R² (결정계수)
r2 = r2_score(y, pred_y)

print(f"✅ RMSE: {rmse:.4f}")
print(f"✅ MPE : {mpe:.2f}%")
print(f"✅ R²   : {r2:.4f}")

# -------------------------------
# 6️⃣ 학습 손실 시각화
# -------------------------------
import matplotlib.pyplot as plt

plt.style.use("ggplot")
plt.figure()
plt.plot(history.history["loss"], label="train_loss")
plt.plot(history.history["val_loss"], label="val_loss")
plt.title("Training Loss (MSE)")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.legend()
plt.show()