'''
#############################################################
     데이터 불러오기 부터
#############################################################

가. 라이브러리 Import
'''

import pandas as pd
import numpy as np


'''
****************************
나. 데이터 불러오기
****************************
Train/Evaluation 데이터를 통합하여 전처리 
     - Train/Evaluation 데이터에 전처리 기준(특히 정규화 작업 시)을 동일하게 함

'''

pd.set_option('display.max_columns', None)  # 컬럼 생략 없이 전부 출력

df_total = pd.read_csv("navi_total.csv",sep=",", index_col=0)
df_total.info()



'''
****************************
1. 이상치/결측치 처리
****************************

-----------------
가. 결측치 처리
-----------------

'''

# 결측치 수 확인하기
df_total.isnull().sum()


# 우리의 학습 데이터에는 결측치가 없습니다. 


'''
-------------------
나. 이상치 처리
-------------------

이상치(Outlier)는 전적으로 연구자 혹은 개발자가 판단.
"자세히 체크해야 함"

'''
import seaborn as sns
import matplotlib.pyplot as plt

sns.pairplot(df_total)
plt.show()  # 오른쪽 상단 변수창의 [Plots]에서 확인, 5초 정도 시간 걸림

# ET의 분포에서 이상치 가능성 체크
#5천 이상으로 숫자을 확인, ET(주행시간) 단위는 초(sec)
df_total[df_total['ET']>5000] 


# Outlier 제거 후 데이터만 남기기
df_total=df_total[df_total['ET']<=5000]
df_total


# 다시 한 번 확인

sns.pairplot(df_total)
plt.show()

'''
눈에 보이는 것만 가지고 판단?
숨겨진 변수 생성 및 확인
평균 시속을 기준으로 분포 체크.
'''

# 평균시속 변수 만들기 : 속도는 거리 나누기 시간
# 거리 단위는 미터
df_total['PerHour']=(df_total['A_DISTANCE']/1000)/(df_total['ET']/3600)


# 데이터 분포 확인하기
df_total.describe()

'''
시속이 137키로?!
'''

# 시속 130이상 데이터 수 확인하기 : 몇 개 되지 않으면 제거하자!
len(df_total[df_total['PerHour']>130])


# Outlier 제거 후 데이터만 남기기
df_total=df_total[df_total['PerHour']<=130]
df_total

# 다시 한 번 확인해 보겠습니다.

sns.pairplot(df_total)
plt.show()   # 시간 걸림, 오른쪽 상단 변수창의 [Plots] 탭에서 확인



'''
수도권으로 한정
'''

df_total['level1_pnu'].unique()

# 서울/경기/인천으로 데이터 정제
df_total=df_total[(df_total['level1_pnu']=='서울특별시')|(df_total['level1_pnu']=='경기도')|(df_total['level1_pnu']=='인천광역시')]
df_total=df_total.reset_index(drop=True)
df_total


'''
**********************************************
3. 더미변수 생성
**********************************************

범주형 데이터도 모델링에 활용 => 딥러닝을 위해서는 숫자형으로 변환 필요
더미변수 기법으로 범주형을 숫자형으로 변환

요일, 시간, 시도 변수를 더미 변수화 

'''

'''
-----------------------------------------
# 진행상황을 체크할 수 있는 tqdm 라이브러리 설치
# 오른쪽 하단 콘솔창에서 다음 코드 입력하여 라이브러리 추가 설피
    pip install tqdm
----------------------------------------
'''

# 요일, 시간 변수 추가
import datetime
from dateutil.parser import parse

# pip install tqdm
from tqdm import tqdm

df_total.info()
weekday_list=[]
hour_list=[]
day_list=[]

# Spyder에서 반복명령 실행할 때, 반복문에 속하는 영역을 마우스로 선택 마킹한 후 run selection 아이콘 클릭
# => 아래 157행 부터 161행까지 마우스로 마킹 선택 후  run selection 아이콘 클릭

for w in tqdm(df_total['TIME_DEPARTUREDATE']):
    parse_data_w=parse(w)
    weekday_list.append(parse_data_w.weekday())  #0: 월, 1:화, 6: 일요일
    hour_list.append(parse_data_w.hour)
    day_list.append(parse_data_w.day)
    
df_total['WEEKDAY'] = weekday_list
df_total['HOUR'] = hour_list
df_total['DAY'] = day_list

df_total

# 평가데이터 별도 저장 : 원본 기준(나중에 활용)
new_df_eval=df_total[df_total['DAY']>=27]
new_df_eval.to_csv("navi_evaluation_new.csv",sep="|",index=False, encoding='utf-8-sig')



dummy_fields = ['WEEKDAY','HOUR','level1_pnu','level2_pnu']

# Spyder에서 반복명령 실행할 때, 반복문에 속하는 영역을 마우스로 선택 마킹한 후 run selection 아이콘 클릭
# => 아래 179행 부터 181행까지 마우스로 마킹 선택 후  run selection 아이콘 클릭
for dummy in dummy_fields:
    dummies = pd.get_dummies(df_total[dummy], prefix=dummy, drop_first=False, dtype=int)
    df_total = pd.concat([df_total, dummies], axis=1)
    
df_total = df_total.drop(dummy_fields,axis=1)
df_total



'''
********************************************
4. 데이터 스케일링
********************************************
Feature들의 크기, 범주를 정규화하는 과정을 통해 특정변수의 영향도를 조정
   - KeyPoint : 데이터 스케일링을 통해 AI모델 학습에 도움을 줄 수 있다.

'''

# 기준일자 저장 : why? 날짜는 스케일링에서 제외.
df_total.info()
data_day=df_total['DAY']

train_data=df_total.drop(['RID','TIME_DEPARTUREDATE','TIME_ARRIVEDATE','ET','ETAA','PerHour','DAY'],axis=1)
train_data.columns
columnNames=train_data.columns
train_data


# 스케일링
from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler(feature_range=(0, 1))
feature = pd.DataFrame(scaler.fit_transform(train_data))
feature.columns=columnNames
feature

# 날짜 열 추가 => Train/Evaluation 분리 목적 

feature['DAY']=data_day
# traindata 지정
train_feature=feature[feature['DAY']<=24]
train_feature=train_feature.drop(['DAY'],axis=1)
eval_feature=feature[feature['DAY']>=27]
eval_feature=eval_feature.drop(['DAY'],axis=1)


len(feature),len(train_feature),len(eval_feature)


# target 저장
train_target = df_total[df_total['DAY']<=24]['ET']
train_target

# CSV로 저장
train_feature.to_csv('navi_train_feature.csv',index = False,sep='|')
train_target.to_csv('navi_train_target.csv',index = False,sep='|')
eval_feature.to_csv('navi_eval_feature.csv',index = False,sep='|')

















