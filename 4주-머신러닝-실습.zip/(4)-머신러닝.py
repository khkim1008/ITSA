'''
#########################################################
[실습-정답] Python을 활용한 AI 모델링 - 머신러닝 파트
#########################################################

- 이번시간에는 Python을 활용한 AI 모델링에서 머신러닝에 대해 실습해 보겠습니다.
- 머신러닝 모델에는 아래와 같이 모델들이 있습니다.
      => 단일 분류예측 모델 : LogisticRegression, KNN, DecisionTree
      => 앙상블(Ensemble) 모델 : RandomForest, XGBoost, LGBM, Stacking, Weighted Blending
- 솔직히, 머신러닝이 딥러닝보다 코딩하기 쉽습니다. 4줄 템플릿에 맞쳐 코딩하면 되기 때문입니다.
- 한가지 당부 드리고 싶은 말은 "백문이불여일타" 입니다.
- 이론보다 실습이 더 많은 시간과 노력이 투자 되어야 합니다.

**********************
학습목차
**********************


1. 머신러닝 모델 프로세스
- 데이터 가져오기
- 데이터 전처리
- Train, Test 데이터셋 분할
- 데이터 정규화
- 단일 분류예측 모델 : LogisticRegression, KNN, DecisionTree
- 앙상블(Ensemble) 모델 : RandomForest, XGBoost, LGBM, Stacking, Weighted Blending

'''

## 1. 실습준비
'''
# 코드실행시 경고 메시지 무시

import warnings
warnings.filterwarnings(action='ignore') 
'''

'''
###########################################
2. 머신러닝 모델 프로세스
###########################################
① 라이브러리 임포트(import)
② 데이터 가져오기(Loading the data)
③ 탐색적 데이터 분석(Exploratory Data Analysis)
④ 데이터 전처리(Data PreProcessing) : 데이터타입 변환, Null 데이터 처리, 누락데이터 처리, 더미특성 생성, 특성 추출 (feature engineering) 등
⑤ Train, Test 데이터셋 분할
⑥ 데이터 정규화(Normalizing the Data)
⑦ 모델 개발(Creating the Model)
⑧ 모델 성능 평가
'''

# ① 라이브러리 임포트

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

'''
② 데이터 로드

cust_data.csv 파일 컬럼명
- 고객등급(class), 성별(sex), 나이(age), 사용서비스수(service), 서비스중지여부 (stop), 미납여부(npay)
- 3 개월 평균 요금(avg_bill), A서비스 3개월 평균요금(A_bill), B서비스 3개월 평균요금(B_bill), 해지여부(termination)
'''

# 앞쪽 전처리에서 저장한 cust_data.csv 파일 읽기
df = pd.read_csv('cust_data.csv')


#③ 데이터 분석

# 13컬럼, 7814 라인
df.info()
df.tail()

# termination 레이블 불균형 
df['termination'].value_counts().plot(kind='bar')
plt.show()


'''
# ④ 데이터 전처리

 - Object 컬럼에 대해 Pandas get_dummies 함수 활용하여 One-Hot-Encoding
'''

# Object 컬럼 리스트 정의
cal_cols = ['class', 'sex', 'stop', 'npay', 'termination', 'bill_rating']

# pandas get_dummies 함수 사용하여 Object 컬럼에 대해 One-Hot-Encoding 수행
df1 = pd.get_dummies(data=df, columns=cal_cols, drop_first=True)


# 19컬럼, 7814 라인
df1.info()

'''
 ⑤ Train, Test 데이터셋 분할
'''

# 입력(X)과 레이블(y) 나누기
# 문제] df1 DataFrame에서 'termination_Y' 컬럼을 제외한 나머지 정보를 X에 저장하세요. 
# DataFrame drop 함수 활용
# 'termination_Y' 컬럼 삭제
# DataFrame에서 values만 X에 저장
from sklearn.model_selection import train_test_split

X = df1.drop('termination_Y', axis=1).values
# DataFrame drop 함수 활용

#[문제] df1 DataFrame에서 'termination_Y' 컬럼의 값을 y로 저장하세요. 
# DataFrame 'termination_Y' 컬럼 사용
# DataFrame에서 values만 y에 저장

y = df1['termination_Y'].values
X.shape, y.shape


# Train , Test dataset 나누기
from sklearn.model_selection import train_test_split

'''
# [문제] Train dataset, Test dataset 나누세요

# Train dataset, Test dataset 나누기 : train_test_split 함수 사용
# 입력 : X, y 
# Train : Test 비율 = 7: 3  --> test_size=0.3
# y Class 비율에 맞게 나주어 주세요 : stratify=y
# 여러번 수행해도 같은 결과 나오게 고정하기 : random_state=42 
# 결과 : X_train, X_test, y_train, y_test
'''
#stratify=y : y의 각 클래스 비율이 train과 test가 동일하게 유지되도록 함 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, stratify=y, random_state=42) 
X_train.shape
y_train.shape

'''
#⑥ 데이터 정규화/스케일링(Normalizing/Scaling)
'''

# 숫자 분포 이루어진 컬럼 확인
df1.tail()
pd.set_option('display.max_columns', None)  # 컬럼 생략 없이 전부 출력
df1.tail()

from sklearn.preprocessing import MinMaxScaler
# [문제] MinMaxScaler 함수를 'scaler'로 정의 하세요. 

# 사이키런의 MinMaxScaler() 함수 활용
# 정의할 결과를 'scaler'로 매핑

scaler = MinMaxScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
X_train[:2], y_train[:2]

# 모델 입력갯수, 출력갯수 확인
X_train.shape

y_train.shape

'''
# ⑦ 모델 개발
'''



# accuracy_eval() =>  모델별 바차트 그려주고 성능 확인을 위한 함수 => 사용자정의 함수 
# 모델별로 Accuracy 점수 저장
# 모델 Accuracy 점수 순서대로 바차트를 그려 모델별로 성능 확인 가능

# 모델명, 예측값, 실제값을 주면 위의 plot_predictions 함수 호출하여 Scatter 그래프 그리며
# 모델별 MSE값을 Bar chart로 그려줌

from sklearn.metrics import accuracy_score

my_predictions = {}


# 마우스로 180행부터 186행까지 부분을 선택(마킹) 한 후 실행(Reu selection 아이콘 클릭)
colors = ['r', 'c', 'm', 'y', 'k', 'khaki', 'teal', 'orchid', 'sandybrown',
          'greenyellow', 'dodgerblue', 'deepskyblue', 'rosybrown', 'firebrick',
          'deeppink', 'crimson', 'salmon', 'darkred', 'olivedrab', 'olive', 
          'forestgreen', 'royalblue', 'indigo', 'navy', 'mediumpurple', 'chocolate',
          'gold', 'darkorange', 'seagreen', 'turquoise', 'steelblue', 'slategray', 
          'peru', 'midnightblue', 'slateblue', 'dimgray', 'cadetblue', 'tomato'
         ]


# 마우스로 accuracy_eval 함수영역 (190행부터 220행까지 부분)을 선택(마킹) 한 후 실행(Reu selection 아이콘 클릭)
def accuracy_eval(name_, pred, actual):
    global predictions
    global colors

    plt.figure(figsize=(12, 9))

    acc = accuracy_score(actual, pred)
    my_predictions[name_] = acc * 100

    y_value = sorted(my_predictions.items(), key=lambda x: x[1], reverse=True)
    
    df = pd.DataFrame(y_value, columns=['model', 'accuracy'])
    print(df)
   
    length = len(df)
    
    plt.figure(figsize=(10, length))
    ax = plt.subplot()
    ax.set_yticks(np.arange(len(df)))
    ax.set_yticklabels(df['model'], fontsize=15)
    bars = ax.barh(np.arange(len(df)), df['accuracy'])
    
    for i, v in enumerate(df['accuracy']):
        idx = np.random.choice(len(colors))
        bars[i].set_color(colors[idx])
        ax.text(v + 2, i, str(round(v, 3)), color='k', fontsize=15, fontweight='bold')
        
    plt.title('accuracy', fontsize=18)
    plt.xlim(0, 100)
    
    plt.show()
                                                         


######################################################################
# 1) 로지스틱 회귀 (LogisticRegression, 분류)
#####################################################################

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.metrics import classification_report

# LogisticRegression 모델 정의하고 학습시키세요. 

# LogisticRegression 함수 사용 및 정의 : lg변수에 저장
# 정의된 LogisticRegression 학습 fit() : 입력값으로 X_train, y_train 준다.


#lg = LogisticRegression()
lg = LogisticRegression(C=1.0, max_iter=2000) #C가 클수록 과적합 위험(S가 곡선모양 가파름), 기본값은 1.0
lg.fit(X_train, y_train)

# 분류기 성능 평가(score)
lg.score(X_test, y_test) # Accuracy평가 => X_test로 예측값 생성후, y_test(실제값)과 비교 


'''
# 분류기 성능 평가 지표
'''

lg_pred = lg.predict(X_test)


# 오차행렬
# TN  FP
# FN  TP

confusion_matrix(y_test, lg_pred) 

# 정확도 : 굉장히 높다
accuracy_score(y_test, lg_pred) 

# 정밀도
precision_score(y_test, lg_pred) 

# 재현율 : 굉장히 낮다.
recall_score(y_test, lg_pred)  

# 정밀도 + 재현율
f1_score(y_test, lg_pred) 


print(classification_report(y_test, lg_pred))

# macro avg: 클래스별 성능을 동등하게 반영

# weighted avg: 클래스별 샘플 수를 고려해 평균

# 바차트 시각화 함수 accuracy_eval() 호출
accuracy_eval('LogisticRegression', lg_pred, y_test) 

# 바차트 시각화 결과는 오른쪽 상단 변수창의 [Plots] 탭에서 확인

##########################################################
'''
2) KNN (K-Nearest Neighbor)
'''
###########################################################

from sklearn.neighbors import KNeighborsClassifier

knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)

knn_pred = knn.predict(X_test)

# 바차트 시각화 함수 accuracy_eval() 호출
accuracy_eval('K-Nearest Neighbor', knn_pred, y_test)
# 바차트 시각화 결과는 오른쪽 상단 변수창의 [Plots] 탭에서 확인


#################################################
'''
3) 결정트리(DecisionTree)
'''
################################################

from sklearn.tree import DecisionTreeClassifier

dt = DecisionTreeClassifier(max_depth=10, random_state=42)
dt.fit(X_train, y_train)

# [문제] 학습된 DecisionTreeClassifier 모델로 예측해 보기 

# DecisionTreeClassifier 학습 모델 : dt
# DecisionTreeClassifier 모델의 predict() 활용 : 입력값으로 X_test
# 결과 : dt_pred 저장

dt_pred = dt.predict(X_test)

# 바차트 시각화 함수 accuracy_eval() 호출
accuracy_eval('DecisionTree', dt_pred, y_test)
# 바차트 시각화 결과는 오른쪽 상단 변수창의 [Plots] 탭에서 확인



'''
---------------------------------------
앙상블 기법의 종류
---------------------------------------

- 배깅 (Bagging): 여러개의 DecisionTree 활용하고 샘플 중복 생성을 통해 결과 도출. RandomForest
- 부스팅 (Boosting): 약한 학습기를 순차적으로 학습을 하되, 이전 학습에 대하여 잘못 예측된 데이터에 가중치를 부여해 오차를 보완해 나가는 방식. XGBoost, LGBM
- 스태킹 (Stacking): 여러 모델을 기반으로 예측된 결과를 통해 Final 학습기(meta 모델)이 다시 한번 예측

'''

#앙상 종류 그림으로 설명

#https://teddylee777.github.io/images/2019-12-18/image-20191217144823555.png

'''
--------------------------------------
4) 랜덤포레스트(RandomForest)
--------------------------------------
    
Bagging 대표적인 모델로써, 훈련셋트를 무작위로 각기 다른 서브셋으로 데이터셋을 만들고
여러개의 DecisonTree로 학습하고 다수결로 결정하는 모델
주요 Hyperparameter

- random_state: 랜덤 시드 고정 값. 고정해두고 튜닝할 것!
- n_jobs: CPU 사용 갯수
- max_depth: 깊어질 수 있는 최대 깊이. 과대적합 방지용
- n_estimators: 앙상블하는 트리의 갯수
- max_features: 최대로 사용할 feature의 갯수. 과대적합 방지용
- min_samples_split: 트리가 분할할 때 최소 샘플의 갯수. default=2. 과대적합 방지용
'''

from sklearn.ensemble import RandomForestClassifier
rfc = RandomForestClassifier(n_estimators=3, random_state=42)  #트리를 3개 생성하겠다.
rfc.fit(X_train, y_train)

rfc_pred = rfc.predict(X_test)

# 바차트 시각화 함수 accuracy_eval() 호출
accuracy_eval('RandomForest Ensemble', rfc_pred, y_test)
# 바차트 시각화 결과는 오른쪽 상단 변수창의 [Plots] 탭에서 확인




'''
----------------------------------------
5) XGBoost
----------------------------------------

- 여러개의 DecisionTree를 결합하여 Strong Learner 만드는 Boosting 앙상블 기법
-  Kaggle 대회에서 자주 사용하는 모델이다.

주요 특징

- scikit-learn 패키지가 아닙니다.
- 성능이 우수함
- GBM보다는 빠르고 성능도 향상되었습니다.
- 여전히 학습시간이 매우 느리다


주요 Hyperparameter

- random_state: 랜덤 시드 고정 값. 고정해두고 튜닝할 것!
- n_jobs: CPU 사용 갯수
- learning_rate: 학습율. 너무 큰 학습율은 성능을 떨어뜨리고, 너무 작은 학습율은 학습이 느리다. 적절한 값을 찾아야함. n_estimators와 같이 튜닝. default=0.1
- n_estimators: 부스팅 스테이지 수. (랜덤포레스트 트리의 갯수 설정과 비슷한 개념). default=100
- max_depth: 트리의 깊이. 과대적합 방지용. default=3.
- subsample: 샘플 사용 비율. 과대적합 방지용. default=1.0
- max_features: 최대로 사용할 feature의 비율. 과대적합 방지용. default=1.0

'''

''' 
----------------------------------------
 오른쪽 Console 창에서 아래 명령어 실행하야 xgboost 패키지 설치
pip install xgboost
-------------------------------------------
'''
# 사이킷런에 xgboost 라이브러리가 없어서 별도로 설치 필요 
# !pip install xgboost
from xgboost import XGBClassifier


xgb = XGBClassifier(n_estimators=3, random_state=42)  
xgb.fit(X_train, y_train)

xgb_pred = xgb.predict(X_test)

# 바차트 시각화 함수 accuracy_eval() 호출
accuracy_eval('XGBoost', xgb_pred, y_test)
# 바차트 시각화 결과는 오른쪽 상단 변수창의 [Plots] 탭에서 확인

'''
-------------------------------------------------
6) Light GBM
-------------------------------------------------

- XGBoost와 함께 주목받는 DecisionTree 알고리즘 기반의 Boosting 앙상블 기법
- XGBoost에 비해 학습시간이 짧은 편이다.

주요 특징

- scikit-learn 패키지가 아닙니다.
- 성능이 우수함
- 속도도 매우 빠릅니다.


주요 Hyperparameter

- random_state: 랜덤 시드 고정 값. 고정해두고 튜닝할 것!
- n_jobs: CPU 사용 갯수
- learning_rate: 학습율. 너무 큰 학습율은 성능을 떨어뜨리고, 너무 작은 학습율은 학습이 느리다. 적절한 값을 찾아야함. n_estimators와 같이 튜닝. default=0.1
- n_estimators: 부스팅 스테이지 수. (랜덤포레스트 트리의 갯수 설정과 비슷한 개념). default=100
- max_depth: 트리의 깊이. 과대적합 방지용. default=3.
- colsample_bytree: 샘플 사용 비율 (max_features와 비슷한 개념). 과대적합 방지용. default=1.0

'''

''' 
----------------------------------------
 오른쪽 Console 창에서 아래 명령어 실행하야 xgboost 패키지 설치
pip install lightgbm
-------------------------------------------
'''
# 사이킷런에 lightgbm 라이브러리가 없어서 별도로 설치 필요 
# !pip install lightgbm
from lightgbm import LGBMClassifier

lgbm = LGBMClassifier(n_estimators=3, random_state=42)  
lgbm.fit(X_train, y_train)

lgbm_pred = lgbm.predict(X_test)

# 바차트 시각화 함수 accuracy_eval() 호출
accuracy_eval('LGBM', lgbm_pred, y_test)
# 바차트 시각화 결과는 오른쪽 상단 변수창의 [Plots] 탭에서 확인

'''
---------------------------------------------
7) Stacking
---------------------------------------------
개별 모델이 예측한 데이터를 기반으로 final_estimator 종합하여 예측을 수행합니다.

- 성능을 극으로 끌어올릴 때 활용하기도 합니다.
- 과대적합을 유발할 수 있습니다. (특히, 데이터셋이 적은 경우)

'''

from sklearn.ensemble import StackingRegressor, StackingClassifier

# 마우스로 479행부터 483행까지를 선택 한 후, 실행(run section 아이콘 클릭)
stack_models = [
    ('LogisticRegression', lg), 
    ('KNN', knn), 
    ('DecisionTree', dt),
]


# stack_models로 선언된 모델(LogisticRegression,KNN,DecisionTree)의 예측결과를 최종 meta_model(final_estimator)을 RandomForest(rfc) 사용하여 분류 예측 

from sklearn.ensemble import RandomForestClassifier
rfc = RandomForestClassifier(n_estimators=3, random_state=42)  #트리를 3개 생성하겠다.
stacking = StackingClassifier(stack_models, final_estimator=rfc, n_jobs=-1) #n_jobs : 병렬처리 여부, 1은 CPU가 1개, 병렬처리 안함 . -1은 모든 CPU 사용



stacking.fit(X_train, y_train)  


stacking_pred = stacking.predict(X_test)

# 바차트 시각화 함수 accuracy_eval() 호출
accuracy_eval('Stacking Ensemble', stacking_pred, y_test)
# 바차트 시각화 결과는 오른쪽 상단 변수창의 [Plots] 탭에서 확인



'''
----------------------------------------
8) Weighted Blending
----------------------------------------\
    
각 모델의 예측값에 대하여 weight를 곱하여 최종 output 계산

-모델에 대한 가중치를 조절하여, 최종 output을 산출합니다.
- 가중치의 합은 1.0이 되도록 합니다.

'''

# 마우스로 518행부터 524행까지를 선택 한 후, 실행(run section 아이콘 클릭)
final_outputs = {
    'DecisionTree': dt_pred, 
    'randomforest': rfc_pred, 
    'xgb': xgb_pred, 
    'lgbm': lgbm_pred,
    'stacking': stacking_pred,
}

# 마우스로 528행부터 533행까지를 선택 한 후, 실행(run section 아이콘 클릭)
# 가중치를 모두 더하면 1이 됨
final_prediction=\
final_outputs['DecisionTree'] * 0.1\
+final_outputs['randomforest'] * 0.2\
+final_outputs['xgb'] * 0.25\
+final_outputs['lgbm'] * 0.15\
+final_outputs['stacking'] * 0.3


# 가중치 계산값이 0.5 초과하면 1, 그렇지 않으면 0
final_prediction = np.where(final_prediction > 0.5, 1, 0)

# 바차트 시각화 함수 accuracy_eval() 호출
accuracy_eval('Weighted Blending', final_prediction, y_test)
# 바차트 시각화 결과는 오른쪽 상단 변수창의 [Plots] 탭에서 확인

'''
#############################################
배운 내용 정리
#############################################

1. 머신러닝 모델 프로세스
   ① 라이브러리 임포트(import)
   ② 데이터 가져오기(Loading the data)
   ③ 탐색적 데이터 분석(Exploratory Data Analysis)
   ④ 데이터 전처리(Data PreProcessing) : 데이터타입 변환, Null 데이터 처리, 누락데이터 처리, 더미특성 생성, 특성 추출 (feature engineering) 등
   ⑤ Train, Test 데이터셋 분할
   ⑥ 데이터 정규화(Normalizing the Data)
   ⑦ 모델 개발(Creating the Model)
   ⑧ 모델 성능 평가
2. 평가 지표 활용 : 모델별 성능 확인을 위한 함수 (가져다 쓰면 된다)
3. 단일 회귀예측 모델 : LogisticRegression, KNN, DecisionTree
4. 앙상블 (Ensemble) : RandomForest, XGBoost, LGBM, Stacking, Weighted Blending


'''


















































