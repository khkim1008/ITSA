'''
###########################################################
[실습] Python을 활용한 AI 모델링 - 딥러닝 파트
###########################################################

- 이번시간에는 Python을 활용한 AI 모델링에서 딥러닝에 대해 실습해 보겠습니다.
- 여기서는 딥러닝 모델 DNN, CNN, RNN 에 대해 코딩하여 모델 구축해 보겠습니다.
- 한가지 당부 드리고 싶은 말은 "백문이불여일타" 입니다.
- 이론보다 실습이 더 많은 시간과 노력이 투자 되어야 합니다.

****************
학습목차
****************

1.실습준비
2. 딥러닝 모델(DNN, CNN, RNN) 프로세스
- 데이터 가져오기
- 데이터 전처리
- Train, Test 데이터셋 분할
- 데이터 정규화
- 딥러닝 모델 : DNN, CNN, RNN

----------------------------------------------------
1. 실습준비
----------------------------------------------------

# 코드실행시 경고 메시지 무시

import warnings
warnings.filterwarnings(action='ignore') 

'''
'''
----------------------------------------------------
2. 딥러닝 모델(DNN, CNN, RNN) 프로세스
----------------------------------------------------
   ① 라이브러리 임포트(import)
   ② 데이터 가져오기(Loading the data)
   ③ 탐색적 데이터 분석(Exploratory Data Analysis)
   ④ 데이터 전처리(Data PreProcessing) : 데이터타입 변환, Null 데이터 처리, 누락데이터 처리, 더미특성 생성, 특성 추출 (feature engineering) 등
   ⑤ Train, Test 데이터셋 분할
   ⑥ 데이터 정규화(Normalizing the Data)
   ⑦ 모델 개발(Creating the Model)
   ⑧ 모델 성능 평가

'''

'''
# ① 라이브러리 임포트
'''

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


'''
# ② 데이터 로드
'''


#고객등급(cust_class), 성별(sex_type), 나이(age), 사용서비스수(service), 서비스중지여부 (stop), 미납여부(npay)
#3개월 평균 요금(avg_bill), A서비스 3개월 평균요금(A_bill), B서비스 3개월 평균요금(b_bill), 해지여부(termination_Y), 요금액수_범주(bill_rating)

df = pd.read_csv('cust_data.csv')


# ③ 데이터 분석

# 12컬럼, 7814 라인
df.info()

df.tail()

# termination 레이블 불균형 
df['termination'].value_counts().plot(kind='bar')  
plt.show()  # => 시각화 결과를 보려면, 오른쪽 상단 변수창에서 [Plots] 탭 클릭하여 확인 

'''
④ 데이터 전처리
Object 컬럼에 대해 Pandas get_dummies 함수 활용하여 One-Hot-Encoding
'''

cal_cols = ['class', 'sex', 'stop', 'npay', 'termination', 'bill_rating']
df1 = pd.get_dummies(data=df, columns=cal_cols, drop_first=True)

# 19컬럼, 7814 라인
df1.info()

'''
# ⑤ Train, Test 데이터셋 분할
'''

from sklearn.model_selection import train_test_split
X = df1.drop('termination_Y', axis=1).values
y = df1['termination_Y'].values


# 마우스로 97행부터 100행까지를 선택 한 후, 실행(run section 아이콘 클릭)
X_train, X_test, y_train, y_test = train_test_split(X, y, 
                                                    test_size=0.3, 
                                                    stratify=y,
                                                    random_state=42)

X_train.shape

y_train.shape

'''
# ⑥ 데이터 정규화/스케일링(Normalizing/Scaling)
'''


pd.set_option('display.max_columns', None)  # 컬럼 생략 없이 전부 출력
# 숫자 분포 이루어진 컬럼 확인
df1.tail()
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

X_train.shape

y_train.shape
X_train[:2]


'''
-------------------
⑦ 모델 개발
-------------------

1) DNN

A. 이진 분류용 DNN layer
- 18개 input layer
- unit 4개 hidden layer
- unit 3개 hidden layer
- 1개 output layer : 이진분류

그림으로 설명 => 아래 URl 참고
https://subscription.packtpub.com/book/data/9781788995207/1/ch01lvl1sec03/deep-learning-intuition

'''


''' 
----------------------------------------
 오른쪽 Console 창에서 아래 명령어 실행하여  tensorflow 패키지 설치
pip install  tensorflow
-------------------------------------------
'''



import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation, Dropout

# 18개 input layer
# unit 4개 hidden layer
# unit 3개 hidden layer 
# 1개 output layser : 이진분류

model = Sequential()
model.add(Dense(4, activation='relu', input_shape=(18,)))
model.add(Dense(3, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

# 모델 확인
model.summary()

# 모델 컴파일 – 이진 분류 모델
# 마우스로 175행부터 177행까지를 선택 한 후, 실행(run section 아이콘 클릭)
model.compile(optimizer='adam', 
              loss='binary_crossentropy', 
              metrics=['accuracy']) 

'''
Dropout : 과적합 방지
그림으로 설명

 https://medium.com/@amarbudhiraja/https-medium-com-amarbudhiraja-learning-less-to-learn-better-dropout-in-deep-machine-learning-74334da4bfc5
'''

model = Sequential()
model.add(Dense(4, activation='relu', input_shape=(18,)))
model.add(Dropout(0.3))
model.add(Dense(3, activation='relu'))
model.add(Dropout(0.3))
model.add(Dense(1, activation='sigmoid'))

model.summary()


# 모델 컴파일 – 이진 분류 모델

model.compile(optimizer='adam', loss='binary_crossentropy',  metrics=['accuracy']) 

# 모델 훈련(학습) 하기
# 마우스로 202행부터 205행까지를 선택 한 후, 실행(run section 아이콘 클릭)
history = model.fit(X_train, y_train,  
                    validation_data=(X_test, y_test), 
                    epochs=20,  
                    batch_size=16)

# 다음과 같이 하나의 행에 표현할 수도 있음
# history = model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=20, batch_size=16)


'''
-----------------------------------------
# ⑧ 모델 성능 평가
-----------------------------------------
성능 시각화
'''

losses = pd.DataFrame(model.history.history)
losses.head()
temp = losses.head()
losses.info()

losses[['loss','val_loss']].plot()
plt.show()
losses[['loss','val_loss', 'accuracy','val_accuracy']].plot()
plt.show()

plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Acc')
plt.legend(['acc', 'val_acc'])
plt.show()


'''
===============================================
 테스트 데이터로 예측
==============================================


# 1) 확률 예측 (sigmoid 출력 → 0~1 확률)
'''

y_proba = model.predict(X_test)


# 2) 분류 결과(0/1)로 변환
y_pred = (y_proba.ravel() >= 0.5).astype(int)


# 3) 성능 지표 확인
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

print("[정확도(Accuracy)] :", accuracy_score(y_test, y_pred))
print("\n[분류 리포트]")
print(classification_report(y_test, y_pred, digits=4))

print("\n[혼동행렬]")
print(confusion_matrix(y_test, y_pred))

# 4) 예측 결과 샘플 확인
print("\n[예측 샘플 10개]")
print("실제:", y_test[:10])
print("예측:", y_pred[:10])
print("확률:", y_proba[:10].ravel())


'''
-------------------------------------
B. 다중 분류용 DNN layer
-------------------------------------
- 18개 input layer
- unit 5개 hidden layer
- dropout
- unit 4개 hidden layer
- dropout
- 2개 output layser : 이진분류

그림으로 설명
https://www.educba.com/dnn-neural-network/
'''

# 18개 input layer
# unit 5개 hidden layer
# dropout
# unit 4개 hidden layer 
# dropout
# 2개 output layser : 다중분류

model = Sequential()
model.add(Dense(5, activation='relu', input_shape=(18,)))
model.add(Dropout(0.3))
model.add(Dense(4, activation='relu'))
model.add(Dropout(0.3))
model.add(Dense(2, activation='softmax'))


model.summary()

# 모델 컴파일 – 다중 분류 모델
# 마우스로 246행부터 248행까지를 선택 한 후, 실행(run section 아이콘 클릭)
model.compile(optimizer='adam', 
              loss='sparse_categorical_crossentropy', 
              metrics=['accuracy']) 


# 모델 훈련(학습) 하기
# 마우스로 253행부터 256행까지를 선택 한 후, 실행(run section 아이콘 클릭)
history = model.fit(X_train, y_train, 
          validation_data=(X_test, y_test),
          epochs=20, 
          batch_size=16)


'''
===============================================
 테스트 데이터로 예측
==============================================


# 1) 확률 예측 (sigmoid 출력 → 0~1 확률)
'''

y_proba = model.predict(X_test)

'''
proba = model.predict(X_test)
y_pred = (proba.ravel() >= 0.5).astype(int)
'''
proba = model.predict(X_test)
y_pred = np.argmax(proba, axis=1)

# 3) 성능 지표 확인
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

print("[정확도(Accuracy)] :", accuracy_score(y_test, y_pred))
print("\n[분류 리포트]")
print(classification_report(y_test, y_pred, digits=4))

print("\n[혼동행렬]")
print(confusion_matrix(y_test, y_pred))

# 4) 예측 결과 샘플 확인
print("\n[예측 샘플 10개]")
print("실제:", y_test[:10])
print("예측:", y_pred[:10])
print("확률:", y_proba[:10].ravel())



'''
-----------------------------------------
# ⑧ 모델 성능 평가
-----------------------------------------
성능 시각화

'''

losses = pd.DataFrame(model.history.history)
losses.head()
temp = losses.head()
losses.info()

losses[['loss','val_loss']].plot()
plt.show()
losses[['loss','val_loss', 'accuracy','val_accuracy']].plot()
plt.show()

plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Acc')
plt.legend(['acc', 'val_acc'])
plt.show()

