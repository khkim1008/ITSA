

'''
===========================
2) CNN
===========================
그림 설명
 https://towardsdatascience.com/a-comprehensive-guide-to-convolutional-neural-networks-the-eli5-way-3bd2b1164a53
 
자체적으로 이미지 수집(충분하지는 않음)

'''
# 이미지 파일 하나 읽어 이미지 보기


import tensorflow as tf
import matplotlib.pyplot as plt

clean_img_path = './IMAGE/clean/000002.jpg'

gfile = tf.io.read_file(clean_img_path)
image = tf.io.decode_image(gfile, dtype=tf.float32)

image.shape   #  TensorShape([384, 512, 3]) : (R, G, B)

plt.imshow(image)
plt.show()

dirty_img_path = './IMAGE/dirty/000001.jpg'

gfile = tf.io.read_file(dirty_img_path)
image = tf.io.decode_image(gfile, dtype=tf.float32)
image.shape
plt.imshow(image)
plt.show()


'''
---------------------
Data Preprocess
---------------------
- tensorflow ImageDataGenerator 함수 활용하여 => 이미지 Data Scaling 및 Train Data/Test Data 분할 설정 
- flow_from_directory 함수 활용하여 => 나누어진 Train 데이터와 Test 데이터에 대해 Batch Size 나누고 , Shuffle하고 labeling 수행

'''
# Hyperparameter Tunning

num_epochs = 50 
batch_size = 4
learning_rate = 0.001   #경사하강법에서 학습률 

input_shape = (384, 512, 3)  # 사이즈 확인
num_classes = 2    # clean, dirty

from tensorflow.keras.preprocessing.image import ImageDataGenerator

# ImageDataGenerator 이용하여 이미지 전처리하기

# 마우스로 60행부터 63행까지를 선택 한 후, 실행(run section 아이콘 클릭)
training_datagen = ImageDataGenerator(
      rescale=1. / 255,
      validation_split=0.2     # train set : 60 * (1 - 0.2) = 49
    )


# 이미지 데이터 읽고 배치, 셔플하고 labeling 수행

# 마우스로 69행부터 76행까지를 선택 한 후, 실행(run section 아이콘 클릭)
training_generator = training_datagen.flow_from_directory(
    './IMAGE/',
    batch_size=batch_size, 
    target_size=(384, 512),       # 이미지 사이즈 강제변환
    class_mode = 'categorical',   # binary , categorical
    shuffle = True,
    subset = 'training'           # training, validation. validation_split 사용하므로 subset 지정
    )

# 마우스로 79행부터 86행까지를 선택 한 후, 실행(run section 아이콘 클릭)
test_generator = training_datagen.flow_from_directory(
    './IMAGE/',
    batch_size=batch_size, 
    target_size=(384, 512),       # 이미지 사이즈 강제변환
    class_mode = 'categorical',   # binary , categorical
    shuffle = True,
    subset = 'validation'         # training, validation. validation_split 사용하므로 subset 지정
    )

# class 이름 및 번호 매핑 확인
print(training_generator.class_indices)

batch_samples = next(iter(training_generator))  #배치 데이터 1개 추출 => 4개의 (이미지 데이터, 레이블)

print('True Value : ',batch_samples[0][0])
print('True Value : ',batch_samples[1][0])
print('True Value : ',batch_samples[1][1])
print('True Value : ',batch_samples[1][2])
print('True Value : ',batch_samples[1][3])

test_image = batch_samples[0][0]
test_label = batch_samples[1][0]
plt.imshow(test_image)   
plt.show()



'''
----------------------
# CNN 모델링
----------------------
'''

#CNN 라이브러리 임포트

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten, Dropout
from tensorflow.keras.layers import Conv2D, MaxPooling2D

# Feature extraction
model = Sequential()
# 32개의 특징맵 생성, 필터크기: 3*3, 
model.add(Conv2D(filters=32, kernel_size=3, activation='relu', input_shape=input_shape)) #특징맵 : 32개
model.add(MaxPooling2D(pool_size=2))
model.add(Conv2D(filters=16, kernel_size=3, activation='relu'))
model.add(MaxPooling2D(pool_size=2))

# Classification
model.add(Flatten())
model.add(Dense(50, activation='relu'))
model.add(Dense(2, activation='softmax'))


model.summary()


# 모델 컴파일 – 이진 분류 모델

#model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate), 
# 마우스로 140행부터 142행까지를 선택 한 후, 실행(run section 아이콘 클릭)
model.compile(optimizer='adam', 
              loss='categorical_crossentropy', 
              metrics=['accuracy']) 


# 모델 훈련(학습) 하기
'''
history = model.fit(training_generator, 
          epochs=20 ,
          steps_per_epoch = len(training_generator) / batch_size,
          validation_steps = len(test_generator) / batch_size,
          validation_data=test_generator, 
          verbose=1
)
'''
import math
# 마우스로 157행부터 163행까지를 선택 한 후, 실행(run section 아이콘 클릭)
history = model.fit(training_generator, #X, y모두 포함
          epochs=20,
          steps_per_epoch = math.ceil(len(training_generator)),         # len(training_generator) => 배치 갯수 => 정수
          validation_steps = math.ceil(len(test_generator)),           #  정수
          validation_data = test_generator,
          verbose=1
)

# 성능 시각화 - 성능평가

import pandas as pd
losses = pd.DataFrame(model.history.history)

losses.head()


losses[['loss','val_loss']].plot()
plt.show()

losses[['loss','val_loss', 'accuracy','val_accuracy']].plot()
plt.show()


plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Acc')
plt.legend(['acc', 'val_acc'])
plt.show()

'''
# 예측하기
'''

# test_generator 샘플 데이터 가져오기
# 배치 사이즈 4 확인

batch_img, batch_label = next(iter(test_generator))
print(batch_img.shape)
print(batch_label.shape)

# 4개 Test 샘플 이미지 그려보고 예측해 보기
import numpy as np
i = 1 
plt.figure(figsize=(16, 30))
for img, label in list(zip(batch_img, batch_label)):
    pred = model.predict(img.reshape(-1,384, 512,3))
    pred_t = np.argmax(pred)
    plt.subplot(8, 4, i)
    plt.title(f'True Value:{np.argmax(label)}, Pred Value: {pred_t}')
    plt.imshow(img)   
    plt.show()
    i = i + 1

'''
-----------------------
# 3) RNN
-----------------------

그림으로 설명 
https://en.wikipedia.org/wiki/File:Recurrent_neural_network_unfold.svg


RNN은 주로 시계열 처리나 자연어 처리에 사용됩니다.
우리 실습에 시계열 데이터나 자연어 관련 데이터가 없어 DNN에서 사용한 Tabular 데이터를 가지고 RNN 실습하도록 하겠습니다.
'''


# RNN 모델링

#RNN 라이브러리 임포트

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten
from tensorflow.keras.layers import LSTM



# ① 라이브러리 임포트
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# ② 데이터 로드


#고객등급(cust_class), 성별(sex_type), 나이(age), 사용서비스수(efct_svc_count), 서비스중지여부 (dt_stop_yn), 미납여부(npay_yn)
#3개월 평균 요금(r3m_avg_bill_amt), A서비스 3개월 평균요금(r3m_A_avg_arpu_amt), B서비스 3개월 평균요금(r3m_B_avg_arpu_amt), 해지여부(termination_yn)

df = pd.read_csv('cust_data.csv')


# ③ 데이터 분석

# 12컬럼, 7814 라인
df.info()

df.tail()

# termination 레이블 불균형 
df['termination'].value_counts().plot(kind='bar')
plt.show()

'''
④ 데이터 전처리
Object 컬럼에 대해 Pandas get_dummies 함수 활용하여 One-Hot-Encoding
'''

cal_cols = ['class', 'sex', 'stop', 'npay', 'termination', 'bill_rating']
df1 = pd.get_dummies(data=df, columns=cal_cols, drop_first=True)

# 19컬럼, 7814 라인
df1.info()

# ⑤ Train, Test 데이터셋 분할
from sklearn.model_selection import train_test_split
X = df1.drop('termination_Y', axis=1).values
y = df1['termination_Y'].values


X_train, X_test, y_train, y_test = train_test_split(X, y, 
                                                    test_size=0.3, 
                                                    stratify=y,
                                                    random_state=42)

X_train.shape

y_train.shape


X_train = X_train.reshape(-1,18,1)  # (18, ) => (배치크기, 열갯수, 채널) => (-1, 18, 1) <= 3차원 텐서 구조로 변환 
X_test = X_test.reshape(-1,18,1)


X_train.shape, X_test.shape

print(type(X_train), X_train.dtype)
print(type(y_train), y_train.dtype)


X_train = np.array(X_train).astype('float32')   # 'int32'도 가능
y_train = np.array(y_train).astype('float32')   # 'int32'도 가능


X_test = np.array(X_test).astype('float32')   # 'int32'도 가능
y_test = np.array(y_test).astype('float32')  # 'int32'도 가능


# define model
model = Sequential()
model.add(LSTM(32, activation='relu', return_sequences=True, input_shape=(18, 1)))
model.add(LSTM(16, activation='relu', return_sequences=True))
model.add(Flatten())
model.add(Dense(8, activation='relu'))
model.add(Dense(1, activation='sigmoid'))


model.summary()

# 모델 컴파일 – 이진 분류 모델

model.compile(optimizer='adam', 
              loss='binary_crossentropy', 
              metrics=['accuracy']) 

#모델 학습

history = model.fit(x=X_train, y=y_train, 
          epochs=10 , batch_size=128,
          validation_data=(X_test, y_test), 
          verbose=1
)


# 성능 시각화 - 성능평가
losses = pd.DataFrame(model.history.history)

losses.head()

losses[['loss','val_loss']].plot()
plt.show()

losses[['loss','val_loss', 'accuracy','val_accuracy']].plot()
plt.show()


plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Acc')
plt.legend(['acc', 'val_acc'])
plt.show()

































